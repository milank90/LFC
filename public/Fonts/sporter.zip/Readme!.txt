Thank for downloading Sporter

NOTE: This font is for PERSONAL USE ONLY! But any donation are very appreciated. 

Paypal account for donation : https://www.paypal.me/blankids

Link to purchase full version and commercial license:
https://fontbundles.net/blankids/306276-sporter-sporty-display-typeface

Please visit our store for more great fonts : 
https://creativemarket.com/bangkit.tri.setiadi

If there is a problem, question, or anything about my fonts, please sent an email to:
blankids.co@gmail.com

Thanks,
blankids Studios